-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Окт 30 2015 г., 08:26
-- Версия сервера: 5.5.25
-- Версия PHP: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `authclient`
--

-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `property` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `config`
--

INSERT INTO `config` (`id`, `property`, `value`) VALUES
(1, 'ping_timeout', '30000'),
(2, 'ping_time', '30000');

-- --------------------------------------------------------

--
-- Структура таблицы `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `user_id` int(11) NOT NULL,
  `key` int(11) NOT NULL,
  `temp_key` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `ip` text NOT NULL,
  `ip_info` text NOT NULL,
  `last_login` bigint(20) NOT NULL,
  `user_key` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`key`,`time`,`last_login`),
  UNIQUE KEY `time` (`time`,`last_login`),
  UNIQUE KEY `key` (`key`,`temp_key`),
  UNIQUE KEY `key_2` (`key`,`temp_key`),
  UNIQUE KEY `id` (`user_id`),
  KEY `FK_388bqadmvaiqbpgr9u5x166pn` (`user_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `temp_key` int(255) NOT NULL,
  `time` bigint(20) NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`user_id`,`time`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `temp_key` (`temp_key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `time` bigint(20) NOT NULL,
  `ip` text NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `comments` text NOT NULL,
  `ban` tinyint(1) NOT NULL,
  `last_login` bigint(20) NOT NULL,
  `max_session` int(11) NOT NULL,
  PRIMARY KEY (`time`,`ban`,`last_login`,`max_session`),
  UNIQUE KEY `time` (`time`,`ban`,`last_login`,`max_session`),
  UNIQUE KEY `time_2` (`time`,`ban`,`last_login`,`max_session`),
  UNIQUE KEY `id` (`id`),
  KEY `time_3` (`time`,`ban`,`last_login`,`max_session`),
  KEY `time_4` (`time`,`ban`,`last_login`,`max_session`),
  KEY `time_5` (`time`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `time`, `ip`, `firstname`, `lastname`, `comments`, `ban`, `last_login`, `max_session`) VALUES
(2, 'login_2', 'login_1', 'example2@mail.com', 0, '', 'Alexander', 'Ivanov', '', 0, 0, 1),
(1, 'login_1', 'login_1', 'example@mail.com', 0, '', 'Ivan', 'Ivanov', '', 0, 0, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `user_key`
--

CREATE TABLE IF NOT EXISTS `user_key` (
  `key` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `max_session` int(11) NOT NULL DEFAULT '1',
  `end_date` timestamp NOT NULL DEFAULT '2019-12-31 22:00:00',
  `last_login` int(11) NOT NULL DEFAULT '0',
  `max_sessions` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`max_session`,`end_date`,`last_login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_key`
--

INSERT INTO `user_key` (`key`, `user_id`, `max_session`, `end_date`, `last_login`, `max_sessions`) VALUES
('uYgu24Uhb643i2Nugb2i', 1, 1, '2018-07-31 21:00:00', 0, NULL),
('7uYgu24Uhb643i2N3333', 2, 2, '2017-02-28 22:00:00', 0, NULL);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `FK_388bqadmvaiqbpgr9u5x166pn` FOREIGN KEY (`user_key`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `FK_ll67hfsoxbb4aj85oexrpq39l` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `user_key`
--
ALTER TABLE `user_key`
  ADD CONSTRAINT `FK_f6p834kedgxkybphsl19kqxjf` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
